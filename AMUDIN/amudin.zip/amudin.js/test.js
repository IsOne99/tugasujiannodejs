let nodejs = 'Hallo Node JS';
console.log(nodejs);